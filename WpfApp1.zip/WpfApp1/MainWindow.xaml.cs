﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net.Http;
using System.Net.Http.Headers;
using System.IO;
using System.Security.Policy;
using static WpfApp1.MainWindow;
using Newtonsoft.Json.Linq;
using static System.Net.Mime.MediaTypeNames;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Xml.Schema;
using System.Windows.Media.Animation;
using System.Collections.Specialized;
using System.Net.Mail;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // List setterit ja getterit
        public class Item
        {
            private string id;
            private string name;
            private string price;
            private string description;

            public Item(string id, string name, string price, string description)
            {
                this.id = id;
                this.name = name;
                this.price = price;
                this.description = description;
            }

            public string Id
            {
                get { return id; }
                set { id = value; }
            }

            public string Name
            {
                get { return name; }
                set { name = value; }
            }
            public string Price
            {
                get { return price; }
                set { price = value; }
            }
            public string Description
            {
                get { return description; }
                set { description = value; }
            }
        }

        // En tiedä mikä tämän funktio on tässä, mutta sitä ei voi poistaa
        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        // Hakee tuotteet Restistä ja lisää ne taulukkoon.
        static public List<Item> getData()
        {
            string uri = "https://www.hmlsolutions.com/cloud13/project/api/get_all.php";
            HttpClient c = new HttpClient();
            Task<string> t = c.GetStringAsync(uri);
            string s = t.Result;
                        var charsToRemove = new string[] { "[", "]", "{", "}", "\"", ":", "id", "nimi", "hinta", "description" };
            foreach (var ch in charsToRemove)
            {
                s = s.Replace(ch, string.Empty);
            }

            List<string> data = s.Split(',').ToList();

            List<Item> ItemList = new List<Item>();

            for (var i = 0; i < data.Count;)
            {
                ItemList.Add(new Item(data.ElementAt(i), data.ElementAt(i + 1), data.ElementAt(i + 2), data.ElementAt(i + 3)));
                i += 4;
            }

            return ItemList;
        }

        // Nappi Fetch Items varten
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            List<Item> ItemList = getData();

            if (datanaytto.Items.Count == 0)
            {
                foreach (var Item in ItemList)
                {
                    datanaytto.Items.Add(Item);
                }
            }
            else if (datanaytto.Items.Count != 0)
            {
                datanaytto.Items.Clear();
                foreach (var Item in ItemList)
                {
                    datanaytto.Items.Add(Item);
                }
            }
        }

        // Nappi uuden tuotteen lisäämiseen
        private void Post_Button_Click(object sender, RoutedEventArgs e)
        {
            var url = "https://hmlsolutions.com/cloud13/project/api/put_send.php";

            var httpRequest = (HttpWebRequest)WebRequest.Create(url);
            httpRequest.Method = "POST";

            httpRequest.ContentType = "application/json";

            string itemName = Name_TextBox.Text;
            string itemPrice = Price_TextBox.Text;
            string itemDescription = Description_TextBox.Text;

            var data = "{\"name\":\""+ itemName + "\",\"price\":\""+ itemPrice +"\",\"description\":\""+itemDescription+"\"}";

            using (var streamWriter = new StreamWriter(httpRequest.GetRequestStream()))
            {
                streamWriter.Write(data);
            }

            var httpResponse = (HttpWebResponse)httpRequest.GetResponse();

            int numericValue;

            if (Name_TextBox.Text == "Enter Name" || Name_TextBox.Text == "" || Price_TextBox.Text == "Enter Price" || Price_TextBox.Text == "" || Description_TextBox.Text == "Enter Description" || Description_TextBox.Text == "")
            {
                MessageBox.Show("Please enter missing values!");
            }
            else if (int.TryParse(itemPrice, out numericValue) != true)
            {
                MessageBox.Show("Please enter a numberic value on Price!");
            }
            else
            {
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                }

                List<Item> ItemList = getData();
                datanaytto.Items.Clear();
                foreach (var Item in ItemList)
                {
                    datanaytto.Items.Add(Item);
                }
            }
        }

        // Tyjää tektiboxit, kun niitä painaa tai niihin siirtyy tabilla
        private void Name_TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            Name_TextBox.Text = "";
        }

        private void Price_TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            Price_TextBox.Text = "";
        }

        private void Description_TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            Description_TextBox.Text = "";
        }
    }
}
